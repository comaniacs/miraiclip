/**
 * Quick-test side panel: tabbed preset cards that drive the SAME public
 * command surface an app (or an AI agent) would — every card is just
 * `project.dispatch(...)`, so everything here is undoable and appears in
 * the document like any other edit.
 */
import type { Project } from "@miraiclip/core";
import { renderEffectsBrowser } from "./effects-browser.js";

export interface PanelContext {
  project: Project;
  playheadUs: () => number;
  durationUs: number;
}

interface Card {
  id: string;
  label: string;
  hint: string;
  /** Toggle cards stay highlighted while active. */
  toggle?: boolean;
  run(context: PanelContext, active: boolean): void;
  disabled?: boolean;
}

interface Tab {
  id: string;
  label: string;
  note?: string;
  cards: Card[];
  /** Custom tab body (instead of cards). Returns a cleanup. */
  render?(body: HTMLElement, getProject: () => Project | undefined): () => void;
}

const fx = (id: string) => `panel-${id}`;

/** Word-timed demo line for the caption cards (300ms per word). */
function demoWords(): { text: string; startUs: number; durationUs: number }[] {
  return "made with miraiclip on the web".split(" ").map((text, i) => ({
    text,
    startUs: i * 300_000,
    durationUs: 300_000,
  }));
}

function addCaptionAtPlayhead(
  context: PanelContext,
  preset: "highlight" | "karaoke" | "pop",
  style?: Record<string, unknown>,
): void {
  const { project, playheadUs, durationUs } = context;
  const words = demoWords();
  const clipDurationUs = words.length * 300_000;
  project.dispatch({
    type: "clip/add",
    payload: {
      kind: "caption",
      id: `caption-${Date.now()}`,
      trackId: "overlay",
      startUs: Math.min(playheadUs(), Math.max(0, durationUs - clipDurationUs)),
      durationUs: clipDurationUs,
      words,
      style: { preset, ...style },
      transform: { y: 0.78 },
    },
  });
}

/**
 * Transition demo: split the video at the playhead, jump the incoming side
 * 1s ahead in the source (so the cut is VISIBLE — a continuous split would
 * make a dissolve between identical frames), then add the transition across
 * the new cut. One transaction — one undo.
 */
function addTransitionAtPlayhead(
  context: PanelContext,
  kind: string,
  params?: Record<string, unknown>,
): void {
  const { project, playheadUs } = context;
  const doc = project.getState().doc;
  const at = Math.round(playheadUs());
  const clip = Object.values(doc.clips).find(
    (c) =>
      c.trackId === "v1" &&
      c.kind === "video" &&
      c.startUs + 600_000 <= at &&
      at <= c.startUs + c.durationUs - 1_600_000,
  );
  if (!clip) {
    console.warn("[panel] park the playhead ≥0.6s into the video and ≥1.6s before its end");
    return;
  }
  const newId = `cut-${Date.now()}`;
  project.transaction(() => {
    project.dispatch({ type: "clip/split", payload: { clipId: clip.id, atUs: at, newClipId: newId } });
    const right = project.getState().doc.clips[newId];
    if (!right || !("trimStartUs" in right)) return;
    project.dispatch({
      type: "clip/trim",
      payload: {
        clipId: newId,
        trimStartUs: right.trimStartUs + 1_000_000,
        durationUs: right.durationUs - 1_000_000,
      },
    });
    project.dispatch({
      type: "transition/add",
      payload: {
        kind,
        fromClipId: clip.id,
        toClipId: newId,
        durationUs: 800_000,
        ...(params ? { params } : {}),
      },
    });
  });
}

const TABS: Tab[] = [
  {
    id: "effects",
    label: "Effects",
    cards: [],
    render: renderEffectsBrowser,
  },
  {
    id: "text",
    label: "Text",
    cards: [
      {
        id: "title", label: "Title", hint: "big, centered, 3s at playhead",
        run: ({ project, playheadUs, durationUs }) =>
          project.dispatch({
            type: "clip/add",
            payload: {
              kind: "text", id: `title-${Date.now()}`, trackId: "overlay",
              startUs: Math.min(playheadUs(), Math.max(0, durationUs - 3_000_000)),
              durationUs: 3_000_000, text: "Big Title", fontSizePx: 72,
              color: "#ffffff", transform: { y: 0.45 },
            },
          }),
      },
      {
        id: "lower", label: "Lower third", hint: "small, bottom-left, 4s",
        run: ({ project, playheadUs, durationUs }) =>
          project.dispatch({
            type: "clip/add",
            payload: {
              kind: "text", id: `lower-${Date.now()}`, trackId: "overlay",
              startUs: Math.min(playheadUs(), Math.max(0, durationUs - 4_000_000)),
              durationUs: 4_000_000, text: "Vinamra Sareen — Miraiclip", fontSizePx: 28,
              color: "#ffd400", transform: { x: 0.22, y: 0.88 },
            },
          }),
      },
      {
        id: "stamp", label: "Timestamp", hint: "shows where you dropped it",
        run: ({ project, playheadUs, durationUs }) => {
          const at = playheadUs();
          project.dispatch({
            type: "clip/add",
            payload: {
              kind: "text", id: `stamp-${Date.now()}`, trackId: "overlay",
              startUs: Math.min(at, Math.max(0, durationUs - 2_000_000)),
              durationUs: 2_000_000, text: `t = ${(at / 1_000_000).toFixed(2)}s`,
              fontSizePx: 36, color: "#8fd18f", transform: { y: 0.12 },
            },
          });
        },
      },
    ],
  },
  {
    id: "animate",
    label: "Animate",
    cards: [
      {
        id: "fadein", label: "Fade in", hint: "opacity 0→1 over 2s, easeInOut",
        run: ({ project }) => {
          project.dispatch({ type: "keyframe/set", payload: { clipId: "main", property: "opacity", timeUs: 0, value: 0, easing: "easeInOut" } });
          project.dispatch({ type: "keyframe/set", payload: { clipId: "main", property: "opacity", timeUs: 2_000_000, value: 1 } });
        },
      },
      {
        id: "zoom", label: "Slow zoom", hint: "scale 1→1.15 across the clip",
        run: ({ project, durationUs }) => {
          project.dispatch({ type: "keyframe/set", payload: { clipId: "main", property: "scale", timeUs: 0, value: 1 } });
          project.dispatch({ type: "keyframe/set", payload: { clipId: "main", property: "scale", timeUs: durationUs, value: 1.15 } });
        },
      },
      {
        id: "slide", label: "Slide in", hint: "x −0.2→0.5 over 1.5s, easeOut",
        run: ({ project }) => {
          project.dispatch({ type: "keyframe/set", payload: { clipId: "main", property: "x", timeUs: 0, value: -0.2, easing: "easeOut" } });
          project.dispatch({ type: "keyframe/set", payload: { clipId: "main", property: "x", timeUs: 1_500_000, value: 0.5 } });
        },
      },
      {
        id: "fadeout", label: "Fade out at end", hint: "last 2s → opacity 0",
        run: ({ project, durationUs }) => {
          project.dispatch({ type: "keyframe/set", payload: { clipId: "main", property: "opacity", timeUs: Math.max(0, durationUs - 2_000_000), value: 1 } });
          project.dispatch({ type: "keyframe/set", payload: { clipId: "main", property: "opacity", timeUs: durationUs, value: 0, easing: "easeIn" } });
        },
      },
      {
        id: "clearkf", label: "Clear animation", hint: "keyframe/clear on the video",
        run: ({ project }) => project.dispatch({ type: "keyframe/clear", payload: { clipId: "main" } }),
      },
    ],
  },
  {
    id: "captions",
    label: "Captions",
    note: "Drops a word-timed demo caption at the playhead — press play to watch the emphasis follow the words.",
    cards: [
      {
        id: "karaoke", label: "Karaoke", hint: "words stay lit as they pass",
        run: (context) => addCaptionAtPlayhead(context, "karaoke"),
      },
      {
        id: "highlight", label: "Highlight", hint: "only the current word lights",
        run: (context) => addCaptionAtPlayhead(context, "highlight"),
      },
      {
        id: "pop", label: "Pop", hint: "current word enlarges + lights",
        run: (context) => addCaptionAtPlayhead(context, "pop"),
      },
      {
        id: "boxed", label: "Boxed karaoke", hint: "with a background box",
        run: (context) =>
          addCaptionAtPlayhead(context, "karaoke", { backgroundColor: "#000000c0", fontSizeFrac: 0.05 }),
      },
    ],
  },
  {
    id: "transitions",
    label: "Transitions",
    note: "Splits the video at the playhead, skips the incoming side 1s ahead (visible cut), and bridges it. Park the playhead mid-video, then scrub back to watch.",
    cards: [
      {
        id: "dissolve", label: "Cross dissolve", hint: "0.8s blend across the cut",
        run: (context) => addTransitionAtPlayhead(context, "crossDissolve"),
      },
      {
        id: "dipblack", label: "Dip to black", hint: "fade out, fade back in",
        run: (context) => addTransitionAtPlayhead(context, "dipToBlack"),
      },
      {
        id: "wipe", label: "Wipe", hint: "edge sweeps right, revealing",
        run: (context) => addTransitionAtPlayhead(context, "wipe", { direction: "right" }),
      },
      {
        id: "slide", label: "Slide", hint: "incoming pushes in leftward",
        run: (context) => addTransitionAtPlayhead(context, "slide", { direction: "left" }),
      },
    ],
  },
];

export function initPanel(root: HTMLElement, getContext: () => PanelContext | undefined): void {
  const tabBar = document.createElement("div");
  tabBar.className = "panel-tabs";
  const body = document.createElement("div");
  body.className = "panel-body";
  root.append(tabBar, body);

  const activeToggles = new Set<string>();

  let cleanup: (() => void) | undefined;

  function renderTab(tab: Tab): void {
    cleanup?.();
    cleanup = undefined;
    body.innerHTML = "";
    root.classList.toggle("wide", !!tab.render);
    for (const button of tabBar.children) {
      button.classList.toggle("active", (button as HTMLElement).dataset["tab"] === tab.id);
    }
    if (tab.note) {
      const note = document.createElement("p");
      note.className = "panel-note";
      note.textContent = tab.note;
      body.append(note);
    }
    if (tab.render) cleanup = tab.render(body, () => getContext()?.project);
    for (const card of tab.cards) {
      const el = document.createElement("button");
      el.className = "card";
      el.disabled = !!card.disabled;
      el.innerHTML = `<strong>${card.label}</strong><span>${card.hint}</span>`;
      const key = `${tab.id}:${card.id}`;
      el.classList.toggle("active", activeToggles.has(key));
      el.addEventListener("click", () => {
        const context = getContext();
        if (!context) return;
        const wasActive = activeToggles.has(key);
        try {
          card.run(context, wasActive);
        } catch (error) {
          console.error("[panel]", error);
          return;
        }
        if (card.toggle) {
          if (wasActive) activeToggles.delete(key);
          else activeToggles.add(key);
          el.classList.toggle("active", !wasActive);
        }
      });
      body.append(el);
    }
    // Undo/redo footer: everything the cards do is plain commands.
    const footer = document.createElement("div");
    footer.className = "panel-footer";
    const undo = document.createElement("button");
    undo.textContent = "Undo";
    undo.addEventListener("click", () => getContext()?.project.undo());
    const redo = document.createElement("button");
    redo.textContent = "Redo";
    redo.addEventListener("click", () => getContext()?.project.redo());
    footer.append(undo, redo);
    body.append(footer);
  }

  for (const tab of TABS) {
    const button = document.createElement("button");
    button.textContent = tab.label;
    button.dataset["tab"] = tab.id;
    button.addEventListener("click", () => renderTab(tab));
    tabBar.append(button);
  }
  renderTab(TABS[0]!);
}

/** Reset toggle highlights when a new file loads (fresh project, fresh stacks). */
export function resetPanel(root: HTMLElement, getContext: () => PanelContext | undefined): void {
  root.innerHTML = "";
  initPanel(root, getContext);
}
